The results of experiments could be found here.

Our results on the ISIC17, ISIC18 and Synapse datasets could be found [here](https://pan.baidu.com/s/1FzDpfBQGz56BH6v2APoymA?pwd=8bqf)